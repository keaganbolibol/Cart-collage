import { NextResponse } from "next/server";
import * as cheerio from "cheerio";

function getHostName(url) {
  try {
    const host = new URL(url).hostname.replace("www.", "");
    return host.split(".")[0].replace(/-/g, " ");
  } catch {
    return "Unknown Store";
  }
}

function findMeta($, name) {
  return (
    $(`meta[property="${name}"]`).attr("content") ||
    $(`meta[name="${name}"]`).attr("content") ||
    ""
  );
}

function extractJsonLdProducts($, url) {
  const items = [];

  $("script[type='application/ld+json']").each((_, el) => {
    try {
      const raw = $(el).text();
      const parsed = JSON.parse(raw);
      const nodes = Array.isArray(parsed) ? parsed : [parsed];

      for (const node of nodes) {
        const graph = node["@graph"] || [node];
        for (const thing of graph) {
          if (thing["@type"] === "Product" || (Array.isArray(thing["@type"]) && thing["@type"].includes("Product"))) {
            const offer = Array.isArray(thing.offers) ? thing.offers[0] : thing.offers || {};
            const image = Array.isArray(thing.image) ? thing.image[0] : thing.image || "";
            items.push({
              store: getHostName(url),
              name: thing.name || "",
              price: Number(offer.price || 0),
              quantity: 1,
              image,
              link: url
            });
          }
        }
      }
    } catch {}
  });

  return items;
}

export async function POST(request) {
  try {
    const { url, mode } = await request.json();

    if (!url) {
      return NextResponse.json({ error: "Missing URL." }, { status: 400 });
    }

    const response = await fetch(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; CartCollageBot/1.0; +https://example.com)",
        "Accept":
          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    });

    if (!response.ok) {
      return NextResponse.json(
        {
          error:
            "I could not open that link. Many carts are private or blocked by the store. Try screenshot import instead."
        },
        { status: 400 }
      );
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    let items = extractJsonLdProducts($, url);

    if (!items.length) {
      const title =
        findMeta($, "og:title") ||
        $("title").text() ||
        "";
      const image =
        findMeta($, "og:image") ||
        findMeta($, "twitter:image") ||
        "";

      const priceText =
        findMeta($, "product:price:amount") ||
        $('[itemprop="price"]').first().attr("content") ||
        $('[itemprop="price"]').first().text() ||
        "";

      const price = Number(String(priceText).replace(/[^0-9.]/g, "")) || 0;

      items = [
        {
          store: getHostName(url),
          name: title.trim(),
          price,
          quantity: 1,
          image,
          link: url
        }
      ];
    }

    if (mode === "cart" && items.length <= 1) {
      return NextResponse.json({
        items,
        warning:
          "This cart link only exposed one item or basic page data. Private carts usually require screenshot import."
      });
    }

    return NextResponse.json({ items });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error.message ||
          "Link import failed. Private carts often cannot be imported by link."
      },
      { status: 500 }
    );
  }
}
